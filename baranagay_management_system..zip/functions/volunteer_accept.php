<?php
include '../components/db_connection.php';
include '../functions/login-checker.php';

// Security check: must be logged in as admin
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: ../admin/login.php");
    exit;
}

// Get volunteer_event_id from URL
$volunteer_event_id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
if (!$volunteer_event_id) {
    header("Location: ../admin/admin_volunteers.php");
    exit;
}

// Update status to 'accepted'
$update_stmt = $conn->prepare("UPDATE volunteer_events SET status = 'accepted' WHERE volunteer_event_id = ?");
$update_stmt->bind_param("i", $volunteer_event_id);

if ($update_stmt->execute()) {
    // Show alert and redirect to admin_volunteer.php
    echo "<script>
        alert('Volunteer status successfully changed to accepted!');
        window.location.href = '../admin/admin_volunteers.php';
    </script>";
    exit;
} else {
    echo "<script>
        alert('Error updating status. Please try again.');
        window.location.href = '../admin/admin_volunteers.php';
    </script>";
}

$update_stmt->close();
$conn->close();
?>
