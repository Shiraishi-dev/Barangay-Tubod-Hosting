<?php
session_start();
include '../components/db_connection.php';
include '../functions/login-checker.php';

// Get today's date once for all queries
$today = date('Y-m-d');

// ✅ Set events to "Ongoing" if they are currently active
$updateOngoingQuery = "
    UPDATE events
    SET status = 'ongoing'
    WHERE ? >= start_date AND ? <= end_date
      AND status != 'ongoing'
      AND status != 'archived'
";
$stmtOngoing = $conn->prepare($updateOngoingQuery);
// Bind $today to both '?' placeholders
$stmtOngoing->bind_param("ss", $today, $today);
$stmtOngoing->execute();
$stmtOngoing->close(); // Good practice to close the statement


// ✅ Automatically archive past events
$updateArchiveQuery = "
    UPDATE events
    SET status = 'archived'
    WHERE end_date < ?
      AND status != 'archived'
";
$stmtArchive = $conn->prepare($updateArchiveQuery);
$stmtArchive->bind_param("s", $today);
$stmtArchive->execute();
$stmtArchive->close(); // Good practice to close the statement


// ✅ Check if the logged-in user is an admin
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$adminName = htmlspecialchars($_SESSION['first_name'] . " " . $_SESSION['last_name']);

// ✅ Fetch all events for display
$result = $conn->query("SELECT * FROM events WHERE status = 'pending' OR status = 'ongoing' ORDER BY event_id DESC");?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="../design/admin.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=notifications" />
    <title>Events List</title>
</head>
<body>
    <?php include '../components/sidebar.php'; ?>
    <main>
        <h1>Events List</h1> <br>
        <a href="../functions/add_event.php"><button>Add Event</button></a>
        <br>
        <div class="event_list">
            <table>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Image</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
                <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['event_id']; ?></td>
                    <td><?php echo htmlspecialchars($row['title']); ?></td>
                    <td><?php echo htmlspecialchars(substr($row['description'], 0, 30)) . '...'; ?></td>
                    <td><img src="../uploads/<?php echo htmlspecialchars($row['image']); ?>" width="100" alt="Event Image"></td>
                    <td><?php echo htmlspecialchars($row['start_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['end_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['status']); ?></td>
                    <td>
                        <a href="../functions/edit_event.php?id=<?php echo $row['event_id']; ?>" class="btn btn-edit">Edit</a>
                        <a href="../functions/delete_event.php?id=<?php echo $row['event_id']; ?>" class="btn btn-delete" onclick="return confirm('Delete this event?')">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </table>
        </div>
    </main>
</body>
</html>
