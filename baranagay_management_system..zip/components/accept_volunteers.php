<?php
include '../components/fetch_accept_volunteers.php';
?>

<?php
// Filter only accepted volunteers
$has_accepted = false;
if ($volunteers_result && $volunteers_result->num_rows > 0) {
?>
    <table>
        <tr>
            <th>Volunteer Event ID</th>
            <th>ID Number</th>
            <th>Name</th>
            <th>Address</th>
            <th>Phone Number</th>
            <th>Reason for Joining</th>
            <th>Joined Date</th>
            <th>Status</th>
        </tr>
        <?php while ($volunteer = $volunteers_result->fetch_assoc()): ?>
            <?php if ($volunteer['status'] !== 'accepted') continue; ?>
            <?php $has_accepted = true; ?>
            <tr>
                <td><?php echo htmlspecialchars($volunteer['volunteer_event_id']); ?></td>
                <td><?php echo htmlspecialchars($volunteer['user_id']); ?></td>
                <td><?php echo htmlspecialchars($volunteer['first_name'] . ' ' . $volunteer['last_name']); ?></td>
                <td><?php echo htmlspecialchars($volunteer['address']); ?></td>
                <td><?php echo htmlspecialchars($volunteer['phone_number'] ?? 'N/A'); ?></td>
                <td><?php echo htmlspecialchars($volunteer['reason'] ?? 'N/A'); ?></td>
                <td><?php echo htmlspecialchars(date("M d, Y H:i", strtotime($volunteer['joined_at']))); ?></td>
                <td><?php echo htmlspecialchars($volunteer['status']); ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
<?php
    if (!$has_accepted) {
        echo "<p>No accepted volunteers for this event.</p>";
    }
} else {
    echo "<p>No accepted volunteers for this event.</p>";
}
?>
