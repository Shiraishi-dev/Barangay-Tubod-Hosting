<?php
include '../components/db_connection.php'; 

// 3. Check if the user is logged in
if(isset($_SESSION['user_id'])){
    $userId = $_SESSION['user_id'];

    // 4. Prepare the SQL query to get ongoing events
    // This query selects events based on several conditions:
    // - The user's status for the event must be 'accepted'.
    // - The current date must be on or after the event's start_date.
    // - The current date must be on or before the event's end_date.
    // CURDATE() is a MySQL function that gets the current date.
    $sql = "SELECT e.title, e.start_date, e.end_date
            FROM events e 
            JOIN volunteer_events ve ON e.event_id = ve.event_id 
            WHERE ve.user_id = ? 
              AND ve.status = 'accepted'
              AND CURDATE() >= e.start_date 
              AND CURDATE() <= e.end_date";
    
    $stmt = $conn->prepare($sql);
    
    // 5. Bind the user_id parameter
    $stmt->bind_param("i", $userId);
    
    // 6. Execute the query
    $stmt->execute();
    
    // 7. Get the result set
    $result = $stmt->get_result();
    
    // 8. Check if any ongoing events were found
    if ($result->num_rows > 0) {
        // Loop through each event and display its details
        while($row = $result->fetch_assoc()) {
            // Reusing the CSS classes from style.css for a consistent look
            echo "<h1> Ongoing Events </h1> <br>";
            echo "<div class='event-item'>";
            echo "    <p class='event-title'>Title: " . htmlspecialchars($row['title']) . "</p>";
            echo "    <p class='event-details'>Starts on: " . htmlspecialchars($row['start_date']) . "</p>";
            echo "    <p class='event-details'>Ends on: " . htmlspecialchars($row['end_date']) . "</p>";
            echo "</div>";
        }
    } else {
        // If no ongoing events are found, display a message
        echo "<p class='message'>No ongoing events</p>";
    }
    
    // 9. Close the statement and the database connection
    $stmt->close();
    $conn->close();
} else {
    // If the user is not logged in, display a message
    echo "<p class='message'>Please log in to see your events.</p>";
}
?>