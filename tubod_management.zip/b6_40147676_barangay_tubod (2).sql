-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql311.byetcluster.com
-- Generation Time: Oct 15, 2025 at 11:53 PM
-- Server version: 11.4.7-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `b6_40147676_barangay_tubod`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `appointment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ngo_name` varchar(255) NOT NULL,
  `proposal_title` varchar(255) NOT NULL,
  `explanation` text NOT NULL,
  `event_date` date NOT NULL,
  `event_time` time NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`appointment_id`, `user_id`, `ngo_name`, `proposal_title`, `explanation`, `event_date`, `event_time`, `status`, `created_at`) VALUES
(1, 13, 'Red Cross', 'Oplan Tuli', 'asdadaasdaaaaaaaaaaaaaaaaaaaaddddddddddddddddaaaaaaaaaaaaaaaaaaad', '2025-10-13', '15:40:00', 'archived', '2025-10-12 07:41:03'),
(2, 13, 'Red Cross', 'Oplan Tuli', 'asdada', '2025-10-13', '15:40:00', 'accepted', '2025-10-12 07:41:56'),
(3, 13, 'asdad', 'adadadadad', 'adada', '2025-10-13', '17:53:00', 'archived', '2025-10-12 07:53:34');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `event_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` varchar(200) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`event_id`, `title`, `description`, `image`, `status`, `start_date`, `end_date`) VALUES
(25, 'Barangay Assembly Day', 'A regular gathering where barangay officials and residents discuss community updates, projects, and concerns. It promotes transparency, participation, and unity among residents.', 'event_68e7b678e2a7b1.60016153.jpg', 'pending', '2025-10-20', '2025-10-21'),
(26, 'Clean-Up Drive', 'A community activity where residents work together to clean streets, public spaces, rivers, and drainage systems. It encourages environmental responsibility and barangay cleanliness.', 'event_68e7b6a6516c27.78988531.jpg', 'pending', '2025-10-27', '2025-10-29'),
(27, 'Medical and Dental Mission', 'Free healthcare services offered to residents in partnership with local health offices or NGOs. Services may include check-ups, dental care, vaccinations, and health education.', 'event_68e7b6e1baca59.93153644.png', 'pending', '2025-11-03', '2025-11-05'),
(28, 'Tree Planting Activity', 'An environmental initiative where volunteers plant trees in designated areas to promote sustainability, reduce carbon emissions, and beautify the barangay.', 'event_68e7b75cd5fda8.95224237.jpg', 'pending', '2025-11-16', '2025-11-18'),
(29, 'Senior Citizens’ Day', 'A special event recognizing and honoring the elderly residents of the barangay. Activities may include free check-ups, games, sharing of stories, and distribution of tokens or groceries.', 'event_68e7b9a0c9c6f0.52970474.webp', 'pending', '2025-10-27', '2025-10-29'),
(31, 'Anti-Drug Campaign / Peace and Order Forumss', 'Programs aimed at raising awareness about drug prevention, peace and order, and community safety. It often involves coordination with local law enforcement agencies.', 'event_68ea0e85ef3813.05521271.jpeg', 'pending', '2025-10-20', '2025-10-21'),
(32, 'Oplan Tuli', 'asdadasd', 'event_68ea2cef6979a9.96255952.jpg', 'archived', '2025-10-11', '2025-10-12'),
(33, 'asdada', 'dadadadad', 'event_68eb4ac671b564.10546506.webp', 'ongoing', '2025-10-15', '2025-10-16'),
(34, 'asda', 'asdadada', 'event_68ee52eadf9612.21966158.jpg', 'archived', '2025-10-14', '2025-10-14');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `content`, `image`, `created_at`) VALUES
(8, 'Youth Sports Tournaments', 'A friendly competition in sports like basketball, volleyball, or sepak takraw, aimed at encouraging sportsmanship, teamwork, and youth engagement.', '1760158193_21458210_703175779873074_7944760921149726098_o.jpg', '2025-10-09 13:22:52');

-- --------------------------------------------------------

--
-- Table structure for table `users_info`
--

CREATE TABLE `users_info` (
  `user_id` int(11) NOT NULL,
  `user_type` enum('resident','admin') NOT NULL DEFAULT 'resident',
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(150) NOT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users_info`
--

INSERT INTO `users_info` (`user_id`, `user_type`, `first_name`, `middle_name`, `last_name`, `username`, `password`, `email`, `profile_image`, `created_at`) VALUES
(1, 'resident', 'Juan', 'Santos', 'Dela Cruz', 'juandelacruz', '123', 'juan.delacruz@example.com', NULL, '2025-09-11 15:56:03'),
(2, 'admin', 'Maria', 'Lopez', 'Santos', 'adminmaria', '$2y$10$kA9jZ2h8P3fjL5C4sWjqU.xkppd5oB1Q9tJX7U7lyuDKH4Z9M5LkC', 'admin.maria@example.com', NULL, '2025-09-11 15:56:14'),
(3, 'resident', 'kim', 'lazagas', 'escobido', 'kimnutsu', '123', 'kimescobido@gmail.com', NULL, '2025-09-11 16:06:56'),
(4, 'resident', 'shiraishi', 'Asuna', 'Manjiro', 'Nero', '$2y$10$dy0VWeBy4DDktd6.q1DtiuEy7/XFQTMHqOMOyWzhfTUEZWLBwh//O', 'kimescobido30@gmail.com', NULL, '2025-09-11 16:36:46'),
(5, 'admin', 'shiraishi', 'Asuna', 'Manjiro', 'admin', '$2y$10$zGt9YWenyo3GgIU07J.yzu4GPlHBeuaGHbtQNoIvgKvhSmZYw.h9C', 'kimescobido0@gmail.com', NULL, '2025-09-11 17:25:19'),
(6, 'admin', 'Kim', 'Lazagas', 'Escobido', 'admin1', '$2y$10$oza1iqAt4.Dw3SukJbxzteSdxg.l8A3VCEvBV/HT7sjQKE7OZKCMa', 'asdada@gmail.com', NULL, '2025-09-11 17:26:42'),
(8, 'resident', 'asda', 'dada', 'dada', 'Nero1', '$2y$10$czjgvW9RCy49HYwHS7o.2eXRSEMTkYfxauIvZ6N7wt4d3.Hq7uddq', 'asdadas@gmail.com', NULL, '2025-09-11 17:31:01'),
(9, 'resident', 'Kim', 'dada', 'Manjiro', 'Nero2', '$2y$10$G16a.l7DSgx7flkE9POl6uXsmlfwXoE7pTFjWqGxkY0aYNjxra.cu', 'kimlazagas.escobido@my.smciligan.edu.ph', NULL, '2025-09-11 17:33:51'),
(10, 'admin', 'sadasda', 'dada', 'dadada', 'Nero3', '$2y$10$HquVmPJ7NOviji1M7kfiTOXWazrsFrC2b1taIwmxsJIo9NoPVao4y', 'kimescobido303@gmail.com', NULL, '2025-09-11 17:34:14'),
(11, 'resident', 'shiraishi', 'Asuna', 'Manjiro', 'Kirito', '$2y$10$jnXP3g6zZfCRSjAtm5AK7.wiLJK3szVf2/BliCgz/7DBW2XEbUSnm', 'kimescobido40@gmail.com', NULL, '2025-10-09 13:53:44'),
(13, 'resident', 'Shiraishi', 'Manjiro', 'Asuna', 'Shiraishi', '$2y$10$K641MH0ZIAm8oUIg0xg8H.1dYFqKlR.6sH9lFOq4fRBEHpurJv4na', 'Asuna@gmail.com', NULL, '2025-10-11 05:49:06');

-- --------------------------------------------------------

--
-- Table structure for table `volunteer_events`
--

CREATE TABLE `volunteer_events` (
  `volunteer_event_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `age` varchar(100) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `reason` text DEFAULT NULL,
  `status` varchar(100) NOT NULL,
  `joined_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `volunteer_events`
--

INSERT INTO `volunteer_events` (`volunteer_event_id`, `user_id`, `event_id`, `address`, `phone_number`, `age`, `sex`, `reason`, `status`, `joined_at`) VALUES
(5, 11, 31, 'Tubod', '099173898085', '23', 'Male', 'Drug Addict', 'accepted', '2025-10-09 13:56:32'),
(6, 8, 31, 'DEL CARMENT', '099173898085', '23', 'Male', 'asdasda', 'accepted', '2025-10-09 14:46:16'),
(7, 9, 31, 'DEL CARMENT', '099173898085', '29', 'Male', 'asda', 'accepted', '2025-10-09 15:51:05'),
(10, 13, 31, 'DEL CARMENT', '099173898085', '23', 'Male', '2asdsada', 'accepted', '2025-10-11 08:44:56'),
(11, 13, 29, 'Tubod', '099123213123', '55', 'Male', 'asdad', 'accepted', '2025-10-11 08:45:11'),
(12, 13, 28, 'Tubod', '099173898085', '33', 'Male', 'sadasd', 'decline', '2025-10-11 08:45:40'),
(13, 13, 27, 'DEL CARMENT', '099173898085', '37', 'Male', '23234', 'accepted', '2025-10-11 09:07:35'),
(14, 13, 32, 'asdad', '02321331', '23', 'Male', 'asdad', 'accepted', '2025-10-11 10:10:12'),
(15, 8, 28, 'DEL CARMENT', '099173898085', '23', 'Female', 'asdada', 'accepted', '2025-10-15 12:22:54'),
(16, 8, 34, 'Tubod', '099123213123', '23', 'Female', 'asdad', 'accepted', '2025-10-15 12:23:03'),
(17, 13, 33, 'Tubod', 'asda', '23', 'Female', 'asdasd', 'accepted', '2025-10-15 13:31:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`appointment_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_info`
--
ALTER TABLE `users_info`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `volunteer_events`
--
ALTER TABLE `volunteer_events`
  ADD PRIMARY KEY (`volunteer_event_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `event_id` (`event_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `appointment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users_info`
--
ALTER TABLE `users_info`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `volunteer_events`
--
ALTER TABLE `volunteer_events`
  MODIFY `volunteer_event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users_info` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `volunteer_events`
--
ALTER TABLE `volunteer_events`
  ADD CONSTRAINT `volunteer_events_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users_info` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `volunteer_events_ibfk_2` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
