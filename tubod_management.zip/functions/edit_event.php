<?php
session_start();
include '../components/db_connection.php';
include '../functions/login-checker.php';


$adminName = htmlspecialchars($_SESSION['first_name'] . " " . $_SESSION['last_name']);
$Idnumber = htmlspecialchars($_SESSION['id_number']);


if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit;
}

if (isset($_GET['id'])) {
    $event_id = intval($_GET['id']);
    $result = $conn->query("SELECT * FROM events WHERE event_id = $event_id");
    $event = $result->fetch_assoc();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    // Handle new image
    if (!empty($_FILES['image']['name'])) {
        $imageTmp = $_FILES['image']['tmp_name'];
        $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $imageName = uniqid('event_', true) . '.' . $ext;
        $targetDir = "../uploads/";

        if (move_uploaded_file($imageTmp, $targetDir . $imageName)) {
            // Remove old image
            if ($event['image'] && file_exists("../uploads/" . $event['image'])) {
                unlink("../uploads/" . $event['image']);
            }
            $event['image'] = $imageName;
        }
    }

    $stmt = $conn->prepare("UPDATE events SET title=?, description=?, image=?, start_date=?, end_date=? WHERE event_id=?");
    $stmt->bind_param("sssssi", $title, $description, $event['image'], $start_date, $end_date, $event_id);
    $stmt->execute();

    header("Location: ../admin/event_admin.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="../design/admin.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=notifications" />
    <title>Document</title>
</head>
<body>
    <?php include '../components/sidebar-side.php'; ?>
    <main>
        <h1>Edit Event</h1>
        <form method="post" enctype="multipart/form-data">
            <p>Title: <input type="text" name="title" value="<?php echo htmlspecialchars($event['title']); ?>" required></p>
            <p>Description: <textarea name="description" required><?php echo htmlspecialchars($event['description']); ?></textarea></p>
            <p>Current Image: <img src="../uploads/<?php echo $event['image']; ?>" width="100"></p>
            <p>New Image: <input type="file" name="image"></p>
            <p>Start Date: <input type="date" name="start_date" value="<?php echo $event['start_date']; ?>" required></p>
            <p>End Date: <input type="date" name="end_date" value="<?php echo $event['end_date']; ?>" required></p>
        <button type="submit">Update Event</button>
        <button><a href="../admin/event_admin.php">Cancel</a></button>
    </form>
    <br>
    </main>
</body>
</html>