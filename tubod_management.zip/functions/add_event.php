<?php
session_start();
include '../components/db_connection.php';
include '../functions/login-checker.php';

$adminName = htmlspecialchars($_SESSION['first_name'] . " " . $_SESSION['last_name']);
$Idnumber = htmlspecialchars($_SESSION['id_number']);

// Only allow admins
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$errorMessage = '';

// --- BACKEND SECURITY CHECK (Crucial and unchanged) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $imageName = null;

    // Check for existing overlapping events before doing anything else
    $overlap_check_stmt = $conn->prepare(
        "SELECT COUNT(*) as count FROM events WHERE ? < end_date AND ? > start_date"
    );
    $overlap_check_stmt->bind_param("ss", $start_date, $end_date);
    $overlap_check_stmt->execute();
    $result = $overlap_check_stmt->get_result();
    $row = $result->fetch_assoc();

    if ($row['count'] > 0) {
        $errorMessage = "Error: The selected date range overlaps with an existing event.";
    } else {
        // --- IMAGE UPLOAD & DATABASE INSERT LOGIC ---
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $imageTmp = $_FILES['image']['tmp_name'];
            $originalName = $_FILES['image']['name'];
            $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
            $allowedExt = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

            if (in_array($ext, $allowedExt)) {
                $imageName = uniqid('event_', true) . '.' . $ext;
                $targetDir = realpath(__DIR__ . '/../uploads');
                if ($targetDir === false) {
                    $targetDir = __DIR__ . '/../uploads';
                    mkdir($targetDir, 0777, true);
                }
                $targetPath = $targetDir . '/' . $imageName;

                if (!move_uploaded_file($imageTmp, $targetPath)) {
                    $errorMessage = "Failed to move uploaded file.";
                }
            } else {
                 $errorMessage = "Invalid image file type. Allowed: jpg, jpeg, png, gif, webp.";
            }
        }

        // Only insert if there were no errors
        if (empty($errorMessage)) {
            $stmt = $conn->prepare("INSERT INTO events (title, description, image, start_date, end_date) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $title, $description, $imageName, $start_date, $end_date);

            if ($stmt->execute()) {
                header("Location: ../admin/event_admin.php");
                exit;
            } else {
                $errorMessage = "Database error: " . $stmt->error;
            }
        }
    }
}

// --- DATA FOR FRONTEND CALENDAR ---
// Fetch all existing event date ranges to pass to JavaScript
$booked_dates_query = "SELECT start_date, end_date FROM events";
$result = $conn->query($booked_dates_query);
$bookedRanges = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $bookedRanges[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="../design/admin.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=notifications" />
    <title>Add New Event</title>
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    
    <style>
        .error-message { color: red; font-weight: bold; margin-top: 10px; }
        /* Makes the date input match the theme better */
        input[type="date"] {
            background-color: white;
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <?php include '../components/sidebar-side.php'; ?>
    <main>
        <h1>Add New Event</h1>

        <?php if (!empty($errorMessage)): ?>
            <p class="error-message"><?php echo $errorMessage; ?></p>
        <?php endif; ?>

        <form class="add_event_sytle" method="post" enctype="multipart/form-data">
            <p>Title: <input type="text" name="title" required></p>
            <p>Description: <textarea name="description" required></textarea></p>
            <p>Image: <input type="file" name="image" required></p>
            
            <p>Start Date:
                <input type="date" id="start_date" name="start_date" placeholder="Select start date..." required>
            </p>
            <p>End Date:
                <input type="date" id="end_date" name="end_date" placeholder="Select end date..." required>
            </p>
            
            <button type="submit" id="submit-button">Add Event</button>
            <button type="button" onclick="window.location.href='../admin/event_admin.php'">Cancel</button>
        </form>
    </main>
    <?php include '../components/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

    <script>
        // Get the booked date ranges from our PHP query
        const bookedRanges = <?php echo json_encode($bookedRanges); ?>;

        // Flatpickr needs ranges in a {from: "YYYY-MM-DD", to: "YYYY-MM-DD"} format.
        // This line converts our database results into that format.
        const disabledDateRanges = bookedRanges.map(range => ({
            from: range.start_date,
            to: range.end_date
        }));

        // Configure the END date picker first
        const endDatePicker = flatpickr("#end_date", {
            dateFormat: "Y-m-d",        // Use the same format as your database (YYYY-MM-DD)
            disable: disabledDateRanges // This is the magic part that disables booked dates
        });

        // Configure the START date picker
        const startDatePicker = flatpickr("#start_date", {
            dateFormat: "Y-m-d",
            disable: disabledDateRanges,
            // This function links the two calendars for a better user experience
            onChange: function(selectedDates, dateStr, instance) {
                // When the start date changes, set the earliest possible end date
                endDatePicker.set('minDate', dateStr);
            }
        });
    </script>
</body>
</html>