<?php
include '../components/db_connection.php';
include '../functions/login-checker.php';

// Sanitize session data
$adminName = htmlspecialchars($_SESSION['first_name'] . " " . $_SESSION['last_name']);
$user_type = htmlspecialchars($_SESSION['user_type']);

// ===================================================
// 1. Total Events
// ===================================================
$eventCount = 0;
$stmt = $conn->prepare("SELECT COUNT(event_id) FROM events");
if ($stmt && $stmt->execute()) {
    $stmt->store_result();
    $stmt->bind_result($eventCount);
    $stmt->fetch();
    $stmt->close();
}

// ===================================================
// 2. Total Volunteers
// ===================================================
$volunteerCount = 0;
$stmt = $conn->prepare("SELECT COUNT(DISTINCT user_id) FROM volunteer_events");
if ($stmt && $stmt->execute()) {
    $stmt->store_result();
    $stmt->bind_result($volunteerCount);
    $stmt->fetch();
    $stmt->close();
}

// ===================================================
// 3. Total Appointments
// ===================================================
$appointmentCount = 0;
$stmt = $conn->prepare("SELECT COUNT(appointment_id) FROM appointments");
if ($stmt && $stmt->execute()) {
    $stmt->store_result();
    $stmt->bind_result($appointmentCount);
    $stmt->fetch();
    $stmt->close();
}

// ===================================================
// 4. Fetch All Events + Pending Volunteer Counts
// ===================================================
$eventPendingCounts = [];
$query = "
    SELECT 
        e.event_id, 
        e.title, 
        COUNT(ve.volunteer_event_id) AS pending_count
    FROM events e
    LEFT JOIN volunteer_events ve 
        ON e.event_id = ve.event_id AND ve.status = 'pending'
    GROUP BY e.event_id, e.title
    ORDER BY e.title ASC
";
$stmt = $conn->prepare($query);
if ($stmt && $stmt->execute()) {
    $stmt->store_result();
    $stmt->bind_result($event_id, $title, $pending_count);

    while ($stmt->fetch()) {
        $eventPendingCounts[] = [
            'event_id' => $event_id,
            'title' => $title,
            'pending_count' => $pending_count
        ];
    }
    $stmt->close();
}

// ===================================================
// 5. Fetch Ongoing Events (based on current date)
// ===================================================
$ongoingEvents = [];
$query = "
    SELECT event_id, title, start_date, end_date 
    FROM events 
    WHERE start_date <= CURDATE() AND end_date >= CURDATE()
    ORDER BY start_date ASC
";
$stmt = $conn->prepare($query);
if ($stmt && $stmt->execute()) {
    $stmt->store_result();
    $stmt->bind_result($event_id, $title, $start_date, $end_date);

    while ($stmt->fetch()) {
        $ongoingEvents[] = [
            'event_id' => $event_id,
            'title' => $title,
            'start_date' => $start_date,
            'end_date' => $end_date
        ];
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="../design/admin.css"> 
</head>
<body>
    <?php include '../components/sidebar.php'; ?>
    <main>
        <h1>Dashboard</h1> <br>

        <div class="dashboard_reports">
            <div class="report-card">
                <h3><?php echo $eventCount; ?></h3>
                <p>Events</p>
            </div>
            <div class="report-card">
                <h3><?php echo $donationCount; ?></h3>
                <p>Donations</p>
            </div>
            <div class="report-card">
                <h3><?php echo $appointmentCount; ?></h3>
                <p>Appointments</p>
            </div>
            <div class="report-card">
                <h3><?php echo $volunteerCount; ?></h3>
                <p>Participants</p>
            </div>
        </div>
        <div class="notifications">
            <div class="events-participants">
                <h1>Events Request Participants</h1>
                <?php if (!empty($eventPendingCounts)): ?>
                    <?php foreach ($eventPendingCounts as $event): ?>
                        <div class="event-item">
                            <p><strong>Event Title:</strong> <?= htmlspecialchars($event['title']); ?></p>
                            <p>Number of Pending Volunteers: <?= htmlspecialchars($event['pending_count']); ?></p>
                        </div>	
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No pending volunteer events right now.</p>
                <?php endif; ?>
            </div>

            <div class="ongoing-events">
                <h1>Ongoing Events</h1>
                <?php if (!empty($ongoingEvents)): ?>
                    <?php foreach ($ongoingEvents as $event): ?>
                        <div class="event-item">
                            <p><strong>Event Title:</strong> <?= htmlspecialchars($event['title']); ?></p>
                            <p>Start Date: <?= htmlspecialchars($event['start_date']); ?></p>
                            <p>End Date: <?= htmlspecialchars($event['end_date']); ?></p>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No ongoing events right now.</p>
                <?php endif; ?>
            </div>
        </div>
        
    </main>
</body>
</html>



