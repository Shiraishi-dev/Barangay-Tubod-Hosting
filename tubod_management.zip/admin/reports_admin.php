<?php
session_start();
include '../components/db_connection.php';
include '../functions/login-checker.php';

// Optional: check if logged in admin
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$adminName = htmlspecialchars($_SESSION['first_name'] . " " . $_SESSION['last_name']);


// Fetch all news
$result = $conn->query("SELECT * FROM news ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="../design/admin.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=notifications" />
    <title>Document</title>
</head>
<body>
    <?php include '../components/sidebar.php'; ?>
    <main>
        <h1>News & Updates</h1> <br>
        <a href="../functions/add_news.php"><button>Add News</button></a>
        <br>
        <div class="event_list">
            <table>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Content</th>
                    <th>Image</th>
                    <th>Date Posted</th>
                    <th>Actions</th>
                </tr>
                <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['title']; ?></td>
                    <td><?php echo substr($row['content'], 0, 80) . '...'; ?></td>
                    <td>
                        <?php if (!empty($row['image'])): ?>
                            <img src="../uploads/<?php echo $row['image']; ?>" width="100">
                        <?php else: ?>
                            No Image
                        <?php endif; ?>
                    </td>
                    <td><?php echo $row['created_at']; ?></td>
                    <td>
                        <a href="../functions/edit_news.php?id=<?php echo $row['id']; ?>" class="btn btn-edit">Edit</a>
                        <a href="../functions/delete_news.php?id=<?php echo $row['id']; ?>" class="btn btn-delete" onclick="return confirm('Delete this news?')">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </table>
        </div>
    </main>
</body>
</html>