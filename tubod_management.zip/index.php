<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'components/db_connection.php';

// Query events
$sql = "SELECT * FROM events ORDER BY event_id DESC";
$result = $conn->query($sql);

// Query news
$sql_news = "SELECT * FROM news ORDER BY created_at DESC";
$result_news = $conn->query($sql_news);

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="design/user.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inria+Serif:wght@700&family=Inter:wght@400;700&display=swap" rel="stylesheet">
    <title>Barangay Tubod</title>
</head>
<body>

    <header>
        <nav class="navbar">
            <a href="index.php" class="navbar-logo"><img src="images/logo.png" alt="Barangay Tubod Logo"></a>
            <div class="main-nav-links">
                <a href="#home">HOME</a>
                <a href="#volunteer">VOLUNTEER</a>
                <a href="#donation">DONATION</a>
                <a href="#events">EVENTS</a>
            </div>
            <div class="nav-action">
                <a href="user/login.php" class="btn btn-primary">JOIN NOW</a>
            </div>
            <button class="nav-toggle" aria-label="toggle navigation">
                <span class="hamburger"></span>
            </button>
        </nav>
    </header>

    <main>
        <section id="home" class="hero-section">
            <h1>Stronger barangay through giving</h1>
            <h2>and serving</h2>
            <h3>Be part of the change! Support our community events by giving and volunteering.</h3>
            <div class="image-container">
                <img src="images/Top1.png" class="image" alt="Community gathering">
            </div>
        </section>

        <section id="volunteer" class="info-section">
            <div class="info-text">
                <h1>Serve with heart,</h1>
                <h2>volunteer with pride</h2>
                <p>Be a volunteer today lend your time, share your skills, and help make our barangay events more meaningful for everyone.</p>
                <a href="#" class="btn btn-secondary">VOLUNTEER NOW</a>
            </div>
            <div class="info-image">
                <img src="images/volunteer.jpg" alt="Volunteer helping community">
            </div>
        </section>

        <section id="donation" class="info-section reverse">
            <div class="info-text">
                <h1>Your generosity is the</h1>
                <h2>heartbeat of our community.</h2>
                <p>Support our community by donating money, food, or any resources that can bring hope and help to those in need.</p>
                <a href="#" class="btn btn-secondary">DONATE NOW</a>
            </div>
            <div class="info-image">
                <img src="images/donation.png" alt="Donation support">
            </div>
        </section>

        <section id="events" class="card-section">
            <h1>Available Events this month</h1>
            <div class="card-container">
                <?php if ($result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): ?>
                        <div class="card">
                            <img src="uploads/<?= htmlspecialchars($row['image']) ?>" alt="<?= htmlspecialchars($row['title']) ?>">
                            <h3><?= htmlspecialchars($row['title']) ?></h3>
                            <p><?= htmlspecialchars($row['description']) ?></p>
                            <div class="card-actions">
                                <?php if ($isLoggedIn): ?>
                                    <a href="join_event.php?id=<?= $row['event_id'] ?>" class="btn btn-primary">JOIN NOW</a>
                                <?php else: ?>
                                    <button onclick="alert('You need to login first before joining an event');" class="btn btn-primary">JOIN NOW</button>
                                <?php endif; ?>
                                <?php if ($isLoggedIn): ?>
                                    <a href="join_event.php?id=<?= $row['event_id'] ?>" class="btn btn-primary">DONATE</a>
                                <?php else: ?>
                                    <button onclick="alert('You need to login first before donating an event');" class="btn btn-secondary-outline">DONATE</button>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p>No events available at the moment.</p>
                <?php endif; ?>
            </div>
        </section>

        <section id="news" class="card-section">
            <h1>Latest News & Updates</h1>
            <div class="card-container">
                <?php if ($result_news->num_rows > 0): ?>
                    <?php while($news = $result_news->fetch_assoc()): ?>
                        <div class="card">
                            <?php if(!empty($news['image'])): ?>
                                <img src="uploads/<?= htmlspecialchars($news['image']) ?>" alt="<?= htmlspecialchars($news['title']) ?>">
                            <?php endif; ?>
                            <h3><?= htmlspecialchars($news['title']) ?></h3>
                            <p><?= nl2br(htmlspecialchars(substr($news['content'], 0, 150))) ?>...</p>
                             <div class="card-actions">
                                <a href="view_news.php?id=<?= $news['id'] ?>" class="btn btn-primary">Read More</a>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p>No news available at the moment.</p>
                <?php endif; ?>
            </div>
        </section>
    </main>

    <footer class="site-footer">
        <p>&copy; <?= date('Y') ?> Barangay Tubod. All rights reserved.</p>
    </footer>
    
    <?php $conn->close(); ?>

    <script>
        const navToggle = document.querySelector('.nav-toggle');
        const navLinks = document.querySelector('.nav-links');
        const navAction = document.querySelector('.nav-action');

        navToggle.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            navAction.classList.toggle('active');
        });
    </script>
</body>
</html>