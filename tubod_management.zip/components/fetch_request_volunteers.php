<?php
include '../components/db_connection.php';

$event_id = filter_input(INPUT_GET, 'event_id', FILTER_SANITIZE_NUMBER_INT);
if (!$event_id) {
    $volunteers_result = false;
    return;
}

$sql = "
    SELECT
        ui.first_name,
        ui.last_name,
        ui.user_id,
        ve.address,
        ve.volunteer_event_id,
        ve.phone_number,
        ve.reason,
        ve.status,
        ve.joined_at
    FROM volunteer_events ve
    JOIN users_info ui ON ve.user_id = ui.user_id
    WHERE ve.event_id = ? AND ve.status = 'pending'
    ORDER BY ve.joined_at DESC
";

$volunteer_stmt = $conn->prepare($sql);
$volunteer_stmt->bind_param("i", $event_id);
$volunteer_stmt->execute();
$volunteers_result = $volunteer_stmt->get_result();
?>
