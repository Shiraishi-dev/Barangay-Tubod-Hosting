<?php
// 1. Start the session to access session variables like user_id
include '../components/db_connection.php';

// 3. Check if the user is logged in by looking for 'user_id' in the session
if(isset($_SESSION['user_id'])){
    $userId = $_SESSION['user_id'];

    // 4. Prepare the SQL query to prevent SQL injection
    // This query selects the event title, status, and join date.
    $sql = "SELECT
    e.title,
    e.status AS event_status,
    ve.status AS volunteer_status,
    ve.joined_at
    FROM
        events e
    JOIN
        volunteer_events ve ON e.event_id = ve.event_id
    WHERE
        ve.user_id = ?
        AND ve.status = 'pending'
        AND (e.status = 'ongoing' OR e.status = 'pending');";
    
    $stmt = $conn->prepare($sql);
    
    // 5. Bind the user_id parameter to the prepared statement
    // "i" specifies that the variable is an integer.
    $stmt->bind_param("i", $userId);
    
    // 6. Execute the query
    $stmt->execute();
    
    // 7. Get the result set from the executed statement
    $result = $stmt->get_result();
    
    // 8. Check if any rows were returned
    if ($result->num_rows > 0) {
        // Loop through each row in the result set
        while($row = $result->fetch_assoc()) {
            // Output the event details using the new custom CSS classes
            echo "<div class='event-item'>";
            echo "    <p class='event-title'>Title: " . htmlspecialchars($row['title']) . "</p>";
            echo "    <p class='event-details'>Event Status: " . htmlspecialchars($row['event_status']) . "</p>";
            echo "    <p class='event-details'>Volunteer Status: " . htmlspecialchars($row['volunteer_status']) . "</p>";
            echo "    <p class='event-details'>Joined at: " . htmlspecialchars($row['joined_at']) . "</p>";
            echo "</div>";
        }
    } else {
        // If no pending events are found, display a message
        echo "<p class='message'>No accepted events</p>";
    }
    
    // 9. Close the statement and the database connection
    $stmt->close();
    $conn->close();
} else {
    // If the user is not logged in, display a message asking them to log in
    echo "<p class='message'>Please log in to see your events.</p>";
}
?>
