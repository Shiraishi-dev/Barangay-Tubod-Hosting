<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include '../components/db_connection.php';
include '../functions/login-checker.php';

// Query events and news
$sql_events = "SELECT * FROM events ORDER BY event_id DESC";
$result_events = $conn->query($sql_events);
$sql_news = "SELECT * FROM news ORDER BY created_at DESC";
$result_news = $conn->query($sql_news);

// Check for session message
$message = '';
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']);
}

// Get user data for the form
$current_user_id = $_SESSION['user_id'] ?? '0';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../design/user.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inria+Serif:wght@700&family=Inter:wght@400;700&display=swap" rel="stylesheet">
    <title>Barangay Tubod Community Hub</title>
</head>
<body>

    <header class="user-header">
        <nav class="user-navbar">
            <a href="../index.php" class="navbar-logo">
                <img src="../images/logo.png" alt="Barangay Tubod Logo">
            </a>

            <div class="main-nav-links">
                <a href="#home">HOME</a>
                <a href="#volunteer">VOLUNTEER</a>
                <a href="#donation">DONATION</a>
                <a href="#events">EVENTS</a>
            </div>

            <div class="profile-dropdown">
                <button class="profile-toggle-btn">
                    <span>Hi, <?= htmlspecialchars($_SESSION['first_name']); ?></span>
                    <span class="dropdown-icon">&#9662;</span> </button>
                <div class="dropdown-content">
                    <a href="profile.php">My Profile</a>
                    <div class="dropdown-divider"></div>
                    <a href="../components/logout.php">Logout</a>
                </div>
            </div>

            <button class="nav-toggle" aria-label="toggle navigation">
                <span class="hamburger"></span>
            </button>
        </nav>
    </header>

<div class="user-page-content">
    </div>

    <main>
        <?php if (!empty($message)): ?>
            <div class="alert-message alert-success">
                <p><?= htmlspecialchars($message) ?></p>
            </div>
        <?php endif; ?>

        <section id="home" class="hero-section">
            <h1>Stronger Barangay Through Giving and Serving</h1>
            <h3>Be part of the change! Support our community events by giving and volunteering.</h3>
            <div class="image-container">
                <img src="../images/Top1.png" class="image" alt="Community gathering at Barangay Tubod">
            </div>
        </section>

        <section id="volunteer" class="info-section">
            <div class="info-text">
                <h2>Serve with heart, volunteer with pride</h2>
                <p>Be a volunteer today lend your time, share your skills, and help make our barangay events more meaningful for everyone.</p>
                <a href="#events" class="btn btn-secondary">VOLUNTEER NOW</a>
            </div>
            <div class="info-image">
                <img src="../images/volunteer.jpg" alt="A volunteer helping an elderly community member">
            </div>
        </section>

        <section id="donation" class="info-section reverse">
            <div class="info-text">
                <h2>Your generosity is the heartbeat of our community.</h2>
                <p>Support our community by donating money, food, or any resources that can bring hope and help to those in need.</p>
                <a href="#" class="btn btn-secondary">DONATE NOW</a>
            </div>
            <div class="info-image">
                <img src="../images/donation.png" alt="Donation box filled with supplies">
            </div>
        </section>

        <section id="events" class="card-section">
            <h2>Available Events This Month</h2>
            <div class="card-container">
                <?php if ($result_events->num_rows > 0): ?>
                    <?php while($row = $result_events->fetch_assoc()): ?>
                        <div class="card">
                            <img src="../uploads/<?= htmlspecialchars($row['image']) ?>" alt="<?= htmlspecialchars($row['title']) ?>">
                            <h3><?= htmlspecialchars($row['title']) ?></h3>
                            <p><?= htmlspecialchars($row['description']) ?></p>
                            <div class="card-actions">
                                <button class="btn btn-primary join-event-btn" 
                                        data-event-id="<?= $row['event_id'] ?>" 
                                        data-event-title="<?= htmlspecialchars($row['title']) ?>">
                                    JOIN NOW
                                </button>
                                <a href="donation_choices.php" class="btn btn-secondary-outline">DONATE</a>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p>No events available at the moment.</p>
                <?php endif; ?>
            </div>
        </section>

        <section id="news" class="card-section">
            <h2>Latest News & Updates</h2>
            <div class="card-container">
                <?php if ($result_news->num_rows > 0): ?>
                    <?php while($news = $result_news->fetch_assoc()): ?>
                        <div class="card">
                            <?php if(!empty($news['image'])): ?>
                                <img src="../uploads/<?= htmlspecialchars($news['image']) ?>" alt="<?= htmlspecialchars($news['title']) ?>">
                            <?php endif; ?>
                            <h3><?= htmlspecialchars($news['title']) ?></h3>
                            <p><?= nl2br(htmlspecialchars(substr($news['content'], 0, 150))) ?>...</p>
                            <div class="card-actions">
                                <a href="view_news.php?id=<?= $news['id'] ?>" class="btn btn-primary">Read More</a>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p>No news available at the moment.</p>
                <?php endif; ?>
            </div>
        </section>
    </main>
    
    <div id="joinEventModal" class="modal">
        <div class="modal-content">
            <span class="close-btn">&times;</span>
            <h2>Join Event: <span id="event-title-placeholder"></span></h2>
            
            <form id="joinForm" action="../functions/handle_volunteer_join.php" method="POST">
                <input type="hidden" name="event_id" id="modal-event-id">
                <input type="hidden" name="user_id" value="<?= htmlspecialchars($current_user_id); ?>">

                <div class="form-group">
                    <label for="address">Street Address</label>
                    <input type="text" id="address" name="address" required>
                </div>
                <div class="form-group">
                    <label for="phone_number">Phone Number (Optional)</label>
                    <input type="tel" id="phone_number" name="phone_number">
                </div>
                <div class="form-group">
                    <label for="age">Age (Must be 18 or above)</label>
                    <input type="number" id="age" name="age" required min="18">
                </div>
                <div class="form-group">
                    <label for="sex">Sex</label>
                    <select id="sex" name="sex">
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="reason">Reason for Joining (Optional)</label>
                    <textarea id="reason" name="reason" rows="3"></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary submit-btn">Submit and Join</button>
            </form>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // --- Mobile Menu Toggle ---
            const navToggle = document.querySelector('.nav-toggle');
            const mainNav = document.querySelector('.main-nav-links');
            
            if (navToggle) {
                navToggle.addEventListener('click', () => {
                    mainNav.classList.toggle('active');
                });
            }

            // --- Profile Dropdown Toggle ---
            const profileToggleBtn = document.querySelector('.profile-toggle-btn');
            const dropdownContent = document.querySelector('.dropdown-content');

            if (profileToggleBtn) {
                profileToggleBtn.addEventListener('click', (event) => {
                    // Stop the click from closing the menu immediately
                    event.stopPropagation(); 
                    dropdownContent.classList.toggle('active');
                    profileToggleBtn.classList.toggle('active');
                });
            }

            // --- Close dropdown when clicking outside of it ---
            document.addEventListener('click', (event) => {
                if (dropdownContent && dropdownContent.classList.contains('active')) {
                    // If the click is outside the dropdown and its toggle button
                    if (!dropdownContent.contains(event.target) && !profileToggleBtn.contains(event.target)) {
                        dropdownContent.classList.remove('active');
                        profileToggleBtn.classList.remove('active');
                    }
                }
            });

            // --- **NEW** Modal Functionality ---
            const modal = document.getElementById('joinEventModal');
            const joinButtons = document.querySelectorAll('.join-event-btn');
            const closeBtn = document.querySelector('.modal .close-btn');
            const eventTitlePlaceholder = document.getElementById('event-title-placeholder');
            const modalEventIdInput = document.getElementById('modal-event-id');

            // Add listener to all "Join Now" buttons
            joinButtons.forEach(button => {
                button.addEventListener('click', () => {
                    const eventId = button.dataset.eventId;
                    const eventTitle = button.dataset.eventTitle;

                    // Populate the modal with the event's data
                    eventTitlePlaceholder.textContent = eventTitle;
                    modalEventIdInput.value = eventId;

                    // Show the modal
                    modal.style.display = 'block';
                });
            });

            // Close the modal when the 'x' is clicked
            if (closeBtn) {
                closeBtn.addEventListener('click', () => {
                    modal.style.display = 'none';
                });
            }

            // Close the modal if user clicks outside of the modal content
            window.addEventListener('click', (event) => {
                if (event.target == modal) {
                    modal.style.display = 'none';
                }
            });
        });
    </script>
    <?php $conn->close(); ?>
</body>
</html>