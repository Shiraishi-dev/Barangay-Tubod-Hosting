<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database connection
include '../components/db_connection.php';
include '../functions/login-checker.php';

// Fetch all user information in one go
$current_user_id = $_SESSION['user_id'] ?? 0;

$sql_events = "SELECT * FROM events ORDER BY event_id DESC";
$result_events = $conn->query($sql_events);


// Corrected SQL query to only select existing columns
$user_info_sql = "SELECT first_name, last_name, user_id, user_type, email FROM users_info WHERE user_id = ?";
$stmt = $conn->prepare($user_info_sql);

// Check if the prepare statement was successful
if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("i", $current_user_id);
$stmt->execute();
$result = $stmt->get_result();

$user = null;
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
}
$stmt->close();

// Handle user info safely
$userName = htmlspecialchars(($user['first_name'] ?? '') . " " . ($user['last_name'] ?? ''));
$user_id = htmlspecialchars($user['user_id'] ?? '');
$usertype = htmlspecialchars($user['user_type'] ?? '');
$email = htmlspecialchars($user['email'] ?? '');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../design/profile.css">
    <link rel="stylesheet" href="../design/donation_form.css"> 
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <title>Make a Donation</title>
</head>
<body>
    <div class="page-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <img src="../images/logo.png" alt="logo" class="sidebar-logo">
            </div>
            <div class="sidebar-profile">
                <img src="../images/prof.png" alt="profile picture" class="profile-image">
                <h2 class="profile-name"><?php echo $userName; ?></h2>
                <p class="profile-role"><?php echo ucfirst($usertype); ?></p>
            </div>
            <ul class="sidebar-menu">
                <li><a href="profile.php"><span class="material-symbols-outlined">person</span>Profile</a></li>
                <li><a href="appointment.php"><span class="material-symbols-outlined">calendar_add_on</span>Make an Appointment</a></li>
                <li><a href="event_donation.php" class="active"><span class="material-symbols-outlined">volunteer_activism</span>Make a Donation</a></li>
                <li><a href="../components/logout.php"><span class="material-symbols-outlined">logout</span>Logout</a></li>
            </ul>
        </aside>

        <div class="main-content-area">
            <nav class="navbar">
                <div class="search-bar">
                </div>
            </nav>

            <main class="content-body">
                <div class="content-header">
                    <h1>Make a Donation</h1>
                </div>
                
                <div class="donation-container">
                    <div class="tab-nav">
                        <button class="tab-button active" data-tab="monetary">Monetary Donation</button>
                        <button class="tab-button" data-tab="material">Material Donation</button>
                    </div>

                    <div id="monetary" class="tab-content active">
                        <h2>Donate via PayPal</h2>
                        <p>Your generous contribution helps us continue our work. Please select an event and enter the amount you wish to donate.</p>
                        <form action="../components/handle_paypal.php" method="POST">
                            <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
                            <div class="form-group">
                                <label for="event_id_money">Select an Event/Campaign</label>
                                <select id="event_id_money" name="event_id" class="form-select" required>
                                    <option value="">-- Choose an Event --</option>
                                    <?php
                                    if ($result_events->num_rows > 0) {
                                        while ($event = $result_events->fetch_assoc()) {
                                            echo '<option value="' . htmlspecialchars($event['event_id']) . '">' . htmlspecialchars($event['title']) . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="amount">Amount (PHP)</label>
                                <input type="number" id="amount" name="amount" class="form-input" min="50" step="1" placeholder="e.g., 500" required>
                            </div>
                            <button type="submit" class="form-button paypal-button">Proceed to PayPal</button>
                        </form>
                    </div>

                    <div id="material" class="tab-content">
                        <h2>Schedule a Material Donation</h2>
                        <p>Your material donations are greatly appreciated. Please describe the items and select a preferred delivery date.</p>
                        <form action="../components/handle_material.php" method="POST">
                            <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
                            <div class="form-group">
                                <label for="event_id_material">Select an Event/Campaign</label>
                                <select id="event_id_material" name="event_id" class="form-select" required>
                                    <option value="">-- Choose an Event --</option>
                                    <?php
                                    // Reset pointer of result set to loop again
                                    $result_events->data_seek(0);
                                    if ($result_events->num_rows > 0) {
                                        while ($event = $result_events->fetch_assoc()) {
                                            echo '<option value="' . htmlspecialchars($event['event_id']) . '">' . htmlspecialchars($event['title']) . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="item_description">Description of Items</label>
                                <textarea id="item_description" name="item_description" class="form-textarea" rows="4" placeholder="e.g., 3 boxes of canned goods, 1 sack of rice" required></textarea>
                            </div>
                            <div class="form-group">
                                <label for="delivery_date">Preferred Delivery Date</label>
                                <input type="date" id="delivery_date" name="delivery_date" class="form-input" min="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            <button type="submit" class="form-button">Schedule Donation</button>
                        </form>
                    </div>
                </div>
                
            </main>
            <?php include '../components/footer.php'; ?>
            </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const tabs = document.querySelectorAll('.tab-button');
            const tabContents = document.querySelectorAll('.tab-content');

            tabs.forEach(tab => {
                tab.addEventListener('click', () => {
                    // Deactivate all tabs and content
                    tabs.forEach(item => item.classList.remove('active'));
                    tabContents.forEach(content => content.classList.remove('active'));

                    // Activate the clicked tab and its corresponding content
                    tab.classList.add('active');
                    document.getElementById(tab.dataset.tab).classList.add('active');
                });
            });
        });
    </script>
</body>
</html>