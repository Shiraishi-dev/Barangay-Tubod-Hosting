<?php
// ==============================================
//  Database Connection - ByetHost Configuration
// ==============================================

// Database credentials
$host   = "sql311.byethost6.com";          // MySQL Hostname
$user   = "b6_40147676";                   // MySQL Username
$pass   = "admin09917398085";              // MySQL Password (keep this secret)
$dbname = "b6_40147676_barangay_tubod";    // MySQL Database Name

// ==============================================
//  Create MySQLi Connection
// ==============================================
$conn = new mysqli($host, $user, $pass, $dbname);

// ==============================================
//  Check Connection
// ==============================================
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Optional: Uncomment for debugging
// echo "Database connected successfully!";
?>
