<?php
include '../components/db_connection.php';
include '../functions/login-checker.php';

// Security check: must be logged in as admin
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// 1. Get and validate event ID from the URL
$event_id = filter_input(INPUT_GET, 'event_id', FILTER_SANITIZE_NUMBER_INT);
if (!$event_id) {
    header("Location: ../admin/event_admin.php");
    exit;
}

$adminName = htmlspecialchars($_SESSION['first_name'] . " " . $_SESSION['last_name']);
$user_type = htmlspecialchars($_SESSION['user_type']);

// Fetch all events (optional)
$result = $conn->query("SELECT * FROM events ORDER BY event_id DESC");

// 2. Fetch the event title for display purposes
$event_stmt = $conn->prepare("SELECT title FROM events WHERE event_id = ?");
$event_stmt->bind_param("i", $event_id);
$event_stmt->execute();
$event_result = $event_stmt->get_result();
$event_data = $event_result->fetch_assoc();
$event_title = $event_data ? htmlspecialchars($event_data['title']) : 'Unknown Event';
$event_stmt->close();

// 3. Fetch ONLY volunteers with Accepted status (case-insensitive)
// 3. Fetch ALL volunteers for this event (any status)
$sql = "
    SELECT
        ui.first_name,
        ui.last_name,
        ui.user_id,
        ve.address,
        ve.volunteer_event_id,
        ve.phone_number,
        ve.reason,
        ve.status,
        ve.joined_at
    FROM volunteer_events ve
    JOIN users_info ui ON ve.user_id = ui.user_id
    WHERE ve.event_id = ? AND ve.status = 'accepted'
    ORDER BY ve.joined_at DESC
";
$volunteer_stmt = $conn->prepare($sql);
$volunteer_stmt->bind_param("i", $event_id);
$volunteer_stmt->execute();
$volunteers_result = $volunteer_stmt->get_result();

?>
