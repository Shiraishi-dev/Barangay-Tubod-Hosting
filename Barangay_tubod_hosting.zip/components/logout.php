<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}   
include '../components/db_connection.php';

session_start();
session_unset();
session_destroy();
header("Location: ../index.php");
exit();
?>
