
<?php 

$adminName = htmlspecialchars($_SESSION['first_name'] . " " . $_SESSION['last_name']);
$user_type = htmlspecialchars($_SESSION['user_type']);

include '../components/db_connection.php';
include '../functions/login-checker.php';
?>
  <aside class="sidebar">
    <div class="sidebar-header">
      <h3>BARANGAY TUBOD<br>MANAGEMENT SYSTEM</h3>
    </div>
    <div class="user-profile">
      <img src="../images/prof.png" alt="profile picture">
      <h2><?php echo $adminName; ?></h2>
      <p class="user-role"><?php echo $user_type?></p>
    </div>
    <ul class="sidebar-nav">
        <li><a href="admin.php" class="active"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
        <li><a href="appointment_list.php" class="active"><i class="fas fa-calendar-plus"></i><span>Appointments</span></a></li>
        <li><a href="event_admin.php"><i class="fas fa-calendar-alt"></i><span>Manage Events</span></a></li>
        <li><a href="admin_volunteers.php"><i class="fas fa-users"></i><span>Volunteers</span></a></li>
        <li><a href=""><i class="fas fa-hand-holding-heart"></i><span>Donations</span></a></li>
        <li><a href="reports_admin.php"><i class="fas fa-newspaper"></i><span>News</span></a></li>
        <li><a href="../admin/archive_events.php"><i class="fas fa-archive"></i><span>Archive Events</span></a></li>
        <li><a href="../components/logout.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></li>
    </ul>
  </aside>