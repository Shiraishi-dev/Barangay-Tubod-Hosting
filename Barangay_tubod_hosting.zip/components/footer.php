<footer class="main-footer">
        &copy; <?php echo date("Y"); ?> Barangay Tubod Volunteer & Donation Management System | Iligan City, Philippines
</footer>