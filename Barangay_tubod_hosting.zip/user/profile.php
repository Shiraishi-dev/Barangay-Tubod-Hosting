<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database connection
include '../components/db_connection.php';
include '../functions/login-checker.php';

// ✅ NEW: include the function file for joined events
include '../functions/displayJoinedEvents.php';

// Fetch all user information in one go
$current_user_id = $_SESSION['user_id'] ?? 0;

// Corrected SQL query to only select existing columns
$user_info_sql = "SELECT first_name, last_name, user_id, user_type, email FROM users_info WHERE user_id = ?";
$stmt = $conn->prepare($user_info_sql);

// Check if the prepare statement was successful
if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("i", $current_user_id);
$stmt->execute();
$result = $stmt->get_result();

$user = null;
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
}
$stmt->close();

// Handle user info safely
$userName = htmlspecialchars(($user['first_name'] ?? '') . " " . ($user['last_name'] ?? ''));
$user_id = htmlspecialchars($user['user_id'] ?? '');
$usertype = htmlspecialchars($user['user_type'] ?? '');
$email = htmlspecialchars($user['email'] ?? '');

// Check for and display session message (success or error)
$message = '';
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']); // Clear the message after displaying it
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../design/profile.css"> 
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <title>User Profile</title>
</head>
<body>
    <div class="page-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                 <img src="../images/logo.png" alt="logo" class="sidebar-logo">
            </div>
            <div class="sidebar-profile">
                <img src="../images/prof.png" alt="profile picture" class="profile-image">
                <h2 class="profile-name"><?php echo $userName; ?></h2>
                <p class="profile-role"><?php echo ucfirst($usertype); ?></p>
            </div>
            <ul class="sidebar-menu">
                <li><a href="profile.php" class="active"><span class="material-symbols-outlined">person</span>Profile</a></li>
                <li><a href="appointment.php"><span class="material-symbols-outlined">calendar_add_on</span>Make an Appointment</a></li>
                <li><a href="../components/logout.php"><span class="material-symbols-outlined">logout</span>Logout</a></li>
            </ul>
        </aside>

        <div class="main-content-area">
            <nav class="navbar">
                <div class="search-bar">
                </div>
            </nav>

            <main class="content-body">
                <div class="content-header">
                    <h1>Profile</h1>
                </div>

                <div class="grid-container">
                    <div class="card personal-info">
                        <h2 class="card-header">Personal Information</h2>
                        <div class="info-grid">
                            <span class="info-label">Full Name</span>
                            <span class="info-data"><?php echo $userName; ?></span>
                            <span class="info-label">ID Number</span>
                            <span class="info-data"><?php echo $user_id; ?></span>
                            <span class="info-label">User Type</span>
                            <span class="info-data"><?php echo $usertype; ?></span>
                            <span class="info-label">Email</span>
                            <span class="info-data"><?php echo $email; ?></span>
                        </div>
                    </div>

                    <div class="card joined-events">
                        <h2 class="card-header">Joined Events History</h2>
                        <div class="events-container">
                             <?php echo displayJoinedEvents($conn, $current_user_id); ?>
                        </div>
                    </div>
                </div>

                <div class="grid-container">
                     <div class="card donated-events">
                         <h2 class="card-header">Donated Events</h2>
                         <div class="empty-state">
                            <span class="material-symbols-outlined empty-icon">sentiment_dissatisfied</span>
                            <p>No donations yet.</p>
                            <span>Find an event to support!</span>
                         </div>
                    </div>

                    <div class="card events-tabs">
                        <h2 class="card-header">Events</h2>
                        <div class="tab-buttons">
                            <button class="tab-button active" onclick="showSection('request', event)">Request</button>
                            <button class="tab-button" onclick="showSection('accept', event)">Accepted</button>
                            <button class="tab-button" onclick="showSection('decline', event)">Declined</button>
                            <button class="tab-button" onclick="showSection('archive', event)">Archived</button>
                        </div>

                        <div id="request" class="tab-content" style="display: block;">
                            <?php include '../components/request_profile.php'; ?>
                        </div>
                        <div id="accept" class="tab-content">
                            <?php include '../components/accept_profile.php'; ?>
                        </div>
                        <div id="decline" class="tab-content">
                            <?php include '../components/decline_profile.php'; ?>
                        </div>
                        <div id="archive" class="tab-content">
                            <?php include '../components/archive_profile.php'; ?>
                        </div>
                    </div>

                    <div class="card ongoing-events">
                        <div class="ongoing-events-content">
                             <?php include '../components/ongoing_profile.php'; ?>
                        </div>
                    </div>
                </div>
                <?php include '../components/footer.php';?>
            </main>
        </div>
    </div>
    
    <script>
        function showSection(sectionId, event) {
            // Hide all tab content
            document.querySelectorAll('.tab-content').forEach(sec => {
                sec.style.display = 'none';
            });

            // Show the target tab content
            const target = document.getElementById(sectionId);
            if (target) {
                target.style.display = 'block';
            }

            // Update active state for buttons
            document.querySelectorAll('.tab-button').forEach(btn => {
                btn.classList.remove('active');
            });
            event.target.classList.add('active');
        }
    </script>
</body>
</html>