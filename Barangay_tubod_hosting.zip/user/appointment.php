<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database connection
include '../components/db_connection.php';
include '../functions/login-checker.php';

// Fetch all user information in one go
$current_user_id = $_SESSION['user_id'] ?? 0;

// Corrected SQL query to only select existing columns
$user_info_sql = "SELECT first_name, last_name, user_id, user_type, email FROM users_info WHERE user_id = ?";
$stmt = $conn->prepare($user_info_sql);

// Check if the prepare statement was successful
if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("i", $current_user_id);
$stmt->execute();
$result = $stmt->get_result();

$user = null;
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
}
$stmt->close();

// Handle user info safely
$userName = htmlspecialchars(($user['first_name'] ?? '') . " " . ($user['last_name'] ?? ''));
$user_id = htmlspecialchars($user['user_id'] ?? '');
$usertype = htmlspecialchars($user['user_type'] ?? '');
$email = htmlspecialchars($user['email'] ?? '');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../design/profile.css"> 
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <title>Make an Appointment</title>
    <style>
        /* CSS for the Appointment Form */
        .appointment-form-card {
            grid-column: 1 / -1; /* Make card span the full width */
        }

        .appointment-form {
            padding: 25px;
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            margin-bottom: 8px;
            font-weight: 500;
            color: #333;
            font-size: 0.9rem;
        }

        .form-group input[type="text"],
        .form-group input[type="date"],
        .form-group input[type="time"],
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-family: 'Poppins', sans-serif;
            font-size: 1rem;
            box-sizing: border-box; 
        }

        .form-group input::placeholder,
        .form-group textarea::placeholder {
            color: #999;
        }

        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }

        .form-row {
            display: flex;
            gap: 20px;
        }

        .form-row .form-group {
            flex: 1;
        }

        .submit-button {
            padding: 12px 25px;
            background-color: #2c7be5; /* Professional blue */
            color: white;
            border: none;
            border-radius: 8px;
            font-family: 'Poppins', sans-serif;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: background-color 0.3s ease;
            align-self: flex-start;
            margin-top: 10px;
        }

        .submit-button:hover {
            background-color: #1a5db3;
        }

    </style>
</head>
<body>
    <div class="page-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <img src="../images/logo.png" alt="logo" class="sidebar-logo">
            </div>
            <div class="sidebar-profile">
                <img src="../images/prof.png" alt="profile picture" class="profile-image">
                <h2 class="profile-name"><?php echo $userName; ?></h2>
                <p class="profile-role"><?php echo ucfirst($usertype); ?></p>
            </div>
            <ul class="sidebar-menu">
                <li><a href="profile.php"><span class="material-symbols-outlined">person</span>Profile</a></li>
                <li><a href="make_appointment.php" class="active"><span class="material-symbols-outlined">calendar_add_on</span>Make an Appointment</a></li>
                <li><a href="../components/logout.php"><span class="material-symbols-outlined">logout</span>Logout</a></li>
            </ul>
        </aside>

        <div class="main-content-area">
            <nav class="navbar">
                <div class="search-bar">
                </div>
            </nav>

            <main class="content-body">
                <div class="content-header">
                    <h1>Make an Appointment</h1>
                </div>

                <div class="grid-container">
                    <div class="card appointment-form-card">
                        <h2 class="card-header">Submit an Event Proposal</h2>
                        
                        <form action="../functions/submit_proposal.php" method="POST" class="appointment-form">
                            <div class="form-group">
                                <label for="ngo_name">NGO (Non-Government Organization)</label>
                                <input type="text" id="ngo_name" name="ngo_name" placeholder="Enter the name of your organization" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="proposal_title">Proposal (Event Title)</label>
                                <input type="text" id="proposal_title" name="proposal_title" placeholder="e.g., Coastal Cleanup Drive" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="explanation">Brief Explanation with the Proposal</label>
                                <textarea id="explanation" name="explanation" rows="5" placeholder="Briefly describe the event's purpose, activities, and expected outcomes." required></textarea>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="event_date">Set Date</label>
                                    <input type="date" id="event_date" name="event_date" required>
                                </div>
                                <div class="form-group">
                                    <label for="event_time">Time</label>
                                    <input type="time" id="event_time" name="event_time" required>
                                </div>
                            </div>
                            
                            <button type="submit" class="submit-button">Submit Proposal</button>
                        </form>
                    </div>
                </div>
                
                <?php include '../components/footer.php'; ?>
            </main>
            </div>
    </div>
</body>
</html>