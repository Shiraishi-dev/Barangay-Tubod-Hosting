<?php
include '../components/db_connection.php';


// --- FIX 1: Corrected SQL Query ---
// The original query was selecting from the 'events' table, but the table displays 'appointment' data.
// This new query joins the necessary tables (appointments, users, ngos) to get all required information.
// It also filters for 'pending' appointments, as that's what an admin would typically manage.
$sql = "
    SELECT 
        ap.appointment_id,
        ap.ngo_name,
        ap.proposal_title,
        ap.explanation,
        ap.event_date,
        ap.event_time,
        ap.status,
        ap.created_at,
        ui.user_id,
        ui.first_name,
        ui.last_name
    FROM 
        appointments AS ap
    JOIN 
        users_info AS ui ON ap.user_id = ui.user_id
    WHERE 
        ap.status = 'pending'
    ORDER BY 
        ap.created_at DESC
";

$appointment_result = $conn->query($sql);
?>
        <h1>Appointment Requests</h1> <br>
        <br>
        <div class="event_list">
            <table>
                    <tr>
                        <th>Appointment ID</th>
                        <th>User ID</th>
                        <th>User Fullname</th>
                        <th>Non-Government Org</th>
                        <th>Proposal Title</th>
                        <th>Explanation</th>
                        <th>Appointment Date</th>
                        <th>Appointment Time</th>
                        <th>Status</th>
                        <th>Submitted</th>
                        <th>Accept</th>
                        <th>Delete</th>
                    </tr>
                <tbody>
                    <?php if ($appointment_result->num_rows > 0): ?>
                        <?php while ($appointment = $appointment_result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($appointment['appointment_id']); ?></td>
                                <td><?php echo htmlspecialchars($appointment['user_id']); ?></td>
                                <td><?php echo htmlspecialchars($appointment['first_name'] . ' ' . $appointment['last_name']); ?></td>
                                <td><?php echo htmlspecialchars($appointment['ngo_name']); ?></td>
                                <td><?php echo htmlspecialchars($appointment['proposal_title']); ?></td>
                                <td><?php echo htmlspecialchars($appointment['explanation'] ?? 'N/A'); ?></td>
                                <td><?php echo htmlspecialchars($appointment['event_date']); ?></td>
                                <td><?php echo htmlspecialchars($appointment['event_time']); ?></td>
                                <td><?php echo htmlspecialchars($appointment['status']); ?></td>
                                <td><?php echo htmlspecialchars($appointment['created_at']); ?></td>
                                <td>
                                    <a href="../functions/appointment_accept.php?id=<?php echo $appointment['appointment_id']; ?>" class="btn btn-view">Accept</a>
                                </td>
                                <td>
                                    <a href="../functions/appointment_decline.php?id=<?php echo $appointment['appointment_id']; ?>" class="btn btn-delete">Decline</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="11" style="text-align: center;">No pending appointment requests found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    <?php $conn->close(); ?>
