<?php
session_start();
include '../components/db_connection.php';
include '../functions/login-checker.php';

// Check if logged in admin
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$adminName = htmlspecialchars($_SESSION['first_name'] . " " . $_SESSION['last_name']);

// --- FIX 1: Corrected SQL Query ---
// The original query was selecting from the 'events' table, but the table displays 'appointment' data.
// This new query joins the necessary tables (appointments, users, ngos) to get all required information.
// It also filters for 'pending' appointments, as that's what an admin would typically manage.
$sql = "
    SELECT 
        ap.appointment_id,
        ap.ngo_name,
        ap.proposal_title,
        ap.explanation,
        ap.event_date,
        ap.event_time,
        ap.status,
        ap.created_at,
        ui.user_id,
        ui.first_name,
        ui.last_name
    FROM 
        appointments AS ap
    JOIN 
        users_info AS ui ON ap.user_id = ui.user_id
    WHERE 
        ap.status = 'pending'
    ORDER BY 
        ap.created_at DESC
";

$appointment_result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="../design/admin.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
</head>
<body>
    <?php include '../components/sidebar.php'; ?>
    <main>
        <br>
        <h2>Appointments Request From (Non-Government Organization)</h2>
        <br>

        <div class="appointment_btn">
            <button class="active" onclick="showSection('request', event)">Request</button>
            <button onclick="showSection('accept', event)">Accept</button>
            <button onclick="showSection('archive', event)">Archive</button>
        </div>

        <div id="request" class="appointment_section">
            <?php include 'request_appointments.php'; ?>
        </div>

        <div id="accept" class="appointment_section" style="display: none;">
            <?php include 'accept_appointments.php'; ?>
        </div>

        <div id="archive" class="appointment_section" style="display: none;">
            <?php include 'archive_appointments.php'; ?>
        </div>

    </main>
    <script>
    function showSection(sectionId, event) {
        // Hide all sections
        document.querySelectorAll('.appointment_section').forEach(sec => {
            sec.style.display = 'none';
        });

        // Show selected section
        const target = document.getElementById(sectionId);
        if (target) {
            target.style.display = 'block';
        }

        // Highlight active button
        document.querySelectorAll('.appointment_btn button').forEach(btn => {
            btn.classList.remove('active');
        });
        event.currentTarget.classList.add('active');
    }
    </script>
</body>
</html>