<?php
session_start();
include '../components/db_connection.php';
include '../functions/login-checker.php';


// Check if logged in admin
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$adminName = htmlspecialchars($_SESSION['first_name'] . " " . $_SESSION['last_name']);

// Fetch all events
$result = $conn->query("SELECT * FROM events WHERE status = 'archived' ORDER BY end_date DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../design/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=notifications" />
    <title>Admin Events Management</title>
</head>
<body>
    <?php include '../components/sidebar.php'; ?>
    <main>
        <h1>Events Volunteer List</h1> <br>
        <br>
        <div class="event_list">
            <table>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Image</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Status</th>
                    <th>Volunteers</th>
                </tr>
                <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['event_id']; ?></td>
                    <td><?php echo $row['title']; ?></td>
                    <td><?php echo substr($row['description'], 0, 30) . '...'; ?></td>
                    <td><img src="../uploads/<?php echo $row['image']; ?>" width="100"></td>
                    <td><?php echo $row['start_date']; ?></td>
                    <td><?php echo $row['end_date']; ?></td>
                    <td><?php echo $row['status']; ?></td>
                    <td>
                        <a href="../functions/view_volunteers.php?event_id=<?php echo $row['event_id']; ?>" class="btn btn-view">VIEW</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </table>
        </div>
    </main>
</body>
</html>
<?php $conn->close(); ?>