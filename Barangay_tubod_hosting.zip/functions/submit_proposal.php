<?php
// Start the session to access session variables
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include the database connection file
include '../components/db_connection.php';

// Check if the form was submitted using the POST method
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // 1. Retrieve and Sanitize Form Data
    $ngo_name = filter_input(INPUT_POST, 'ngo_name', FILTER_SANITIZE_STRING);
    $proposal_title = filter_input(INPUT_POST, 'proposal_title', FILTER_SANITIZE_STRING);
    $explanation = filter_input(INPUT_POST, 'explanation', FILTER_SANITIZE_STRING);
    $event_date = trim($_POST['event_date']);
    $event_time = trim($_POST['event_time']);

    // 2. Get the current user's ID from the session
    if (!isset($_SESSION['user_id'])) {
        echo "<script>
            alert('You must be logged in to submit a proposal.');
            window.location.href = '../user/login.php';
        </script>";
        exit();
    }
    $user_id = $_SESSION['user_id'];

    // 3. Check for scheduling conflicts
    $check_sql = "SELECT appointment_id 
                  FROM appointments 
                  WHERE event_date = ? 
                  AND ABS(TIMEDIFF(event_time, ?)) < '01:00:00'";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("ss", $event_date, $event_time);
    $check_stmt->execute();
    $check_stmt->store_result();

    if ($check_stmt->num_rows > 0) {
        // Conflict found — alert user
        echo "<script>
            alert('This timeslot is unavailable. Please choose a time at least 1 hour before or after any existing appointment on this date.');
            window.location.href = '../user/appointment.php';
        </script>";
        $check_stmt->close();
        $conn->close();
        exit();
    }
    $check_stmt->close();

    // 4. Prepare the SQL INSERT Statement
    $sql = "INSERT INTO appointments (user_id, ngo_name, proposal_title, explanation, event_date, event_time, status) 
            VALUES (?, ?, ?, ?, ?, ?, 'pending')";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        echo "<script>
            alert('Error preparing the database query.');
            window.location.href = '../user/appointment.php';
        </script>";
        exit();
    }

    // 5. Bind Parameters and Execute
    $stmt->bind_param("isssss", $user_id, $ngo_name, $proposal_title, $explanation, $event_date, $event_time);

    // 6. Feedback messages
    if ($stmt->execute()) {
        echo "<script>
            alert('Your proposal has been submitted successfully!');
            window.location.href = '../user/appointment.php';
        </script>";
    } else {
        echo "<script>
            alert('There was an error submitting your proposal. Please try again.');
            window.location.href = '../user/appointment.php';
        </script>";
    }

    $stmt->close();
    $conn->close();
    exit();

} else {
    // If accessed directly, redirect to the form
    header("Location: ../user/appointment.php");
    exit();
}
?>
