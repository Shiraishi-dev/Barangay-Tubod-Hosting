<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

include '../components/db_connection.php';
include '../functions/login-checker.php';
include '../components/fetch_request_volunteers.php';
include '../components/fetch_accept_volunteers.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <title>Volunteers for <?php echo $event_title; ?></title>
    <link rel="stylesheet" href="../design/admin.css">
</head>
<body>
    <?php include '../components/sidebar-side.php'; ?>
    <main>
        <h1>Volunteers for Event: <?php echo $event_title; ?></h1> <br>
        <a href="../admin/admin_volunteers.php"><button>← Back to Events List</button></a>
        <br><br>

        <div class="volunteer_details">
                <div class="appointment_btn">
                    <button class="active" onclick="showSection('request', event)">Request</button>
                    <button onclick="showSection('accept', event)">Accept</button>
                </div>

                <!-- Request Section -->
                <div id="request" class="appointment_section" style="display: block;">
                    <?php include '../components/request_volunteers.php'; ?>
                </div>

                <!-- Accept Section -->
                <div id="accept" class="appointment_section">
                    <?php include '../components/accept_volunteers.php'; ?>
                </div>
        </div>
    </main>

    <script>
    function showSection(sectionId, event) {
        document.querySelectorAll('.appointment_section').forEach(sec => {
            sec.style.display = 'none';
        });

        const target = document.getElementById(sectionId);
        if (target) {
            target.style.display = 'block';
        }

        document.querySelectorAll('.appointment_btn button').forEach(btn => {
            btn.classList.remove('active');
        });
        event.target.classList.add('active');
    }
    </script>

</body>
</html>

<?php 
if (isset($volunteer_stmt)) {
    $volunteer_stmt->close();
}
$conn->close(); 
?>
