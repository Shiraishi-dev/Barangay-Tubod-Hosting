<?php
session_start();
include '../components/db_connection.php';
include '../functions/login-checker.php';

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit;
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Fetch image filename before deleting the record
    $res = $conn->query("SELECT image FROM news WHERE id = $id");
    if ($res && $res->num_rows > 0) {
        $row = $res->fetch_assoc();
        $imagePath = "../uploads/" . $row['image'];

        // Delete image file if it exists
        if (!empty($row['image']) && file_exists($imagePath)) {
            unlink($imagePath);
        }
    }

    // Delete news record
    $sql = "DELETE FROM news WHERE id = $id";
    if ($conn->query($sql)) {
        header("Location: ../admin/reports_admin.php"); // ✅ correct redirect
        exit;
    } else {
        echo "Error deleting news: " . $conn->error;
    }
} else {
    header("Location: ../admin/admin.php");
    exit;
}
