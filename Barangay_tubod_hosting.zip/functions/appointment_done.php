<?php
include '../components/db_connection.php';

// Check if ID is passed
if (isset($_GET['id'])) {
    $appointment_id = intval($_GET['id']); // sanitize input

    // Prepare SQL query
    $stmt = $conn->prepare("UPDATE appointments SET status = 'archived' WHERE appointment_id = ?");
    $stmt->bind_param("i", $appointment_id);

    if ($stmt->execute()) {
        echo "
        <script>
            alert('Appointment has been moved to Archived successfully!');
            window.location.href = '../admin/appointment_list.php';
        </script>
        ";
    } else {
        echo "
        <script>
            alert('Error updating appointment status.');
            window.location.href = '../admin/appointment_list.php';
        </script>
        ";
    }

    $stmt->close();
} else {
    echo "
    <script>
        alert('No appointment ID provided.');
        window.location.href = '../admin/appointment_list.php';
    </script>
    ";
}

$conn->close();
?>
