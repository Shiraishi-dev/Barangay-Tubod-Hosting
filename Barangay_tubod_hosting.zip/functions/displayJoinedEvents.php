<?php
function displayJoinedEvents($conn, $userId) {
    $sql = "
        SELECT 
            e.event_id,
            e.title AS event_title,
            e.description AS event_description,
            e.image AS event_image,
            e.start_date,
            ve.status
        FROM volunteer_events ve
        INNER JOIN events e ON ve.event_id = e.event_id
        WHERE ve.user_id = ?
        ORDER BY ve.joined_at DESC
    ";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return "<p>Error preparing query: " . $conn->error . "</p>";
    }

    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        return "<p style='color: #bbb; padding: 20px;'>No joined events yet.</p>";
    }

    $output = "<div class='event-card-container'>";
    while ($row = $result->fetch_assoc()) {
        $eventId = htmlspecialchars($row['event_id']);
        $eventTitle = htmlspecialchars($row['event_title']);
        $eventDesc = htmlspecialchars($row['event_description']);
        $eventImg = !empty($row['event_image']) 
        ? '../uploads/' . basename($row['event_image'])
        : '../images/default-event.jpg';
        $startDate = date("M d, Y", strtotime($row['start_date']));
        $status = htmlspecialchars($row['status']);

        $output .= "
        <div class='event-card'>
            <div class='event-image'>
                <img src='{$eventImg}' alt='{$eventTitle}'>
            </div>
            <div class='event-info'>
                <h3>{$eventTitle}</h3>
                <p class='date'>{$startDate}</p>
            </div>
            <div class='event-actions'>
                <span class='material-symbols-outlined'>more_vert</span>
            </div>
        </div>";
    }
    $output .= "</div>";

    $stmt->close();
    return $output;
}
?>
