<?php
session_start();
include '../components/db_connection.php';
include '../functions/login-checker.php';

$adminName = htmlspecialchars($_SESSION['first_name'] . " " . $_SESSION['last_name']);
$Idnumber = htmlspecialchars($_SESSION['id_number']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $conn->real_escape_string($_POST['title']);
    $content = $conn->real_escape_string($_POST['content']);

    // Handle file upload
    $imageName = null;
    if (!empty($_FILES['image']['name'])) {
        $targetDir = "../uploads/"; // ✅ go up one folder to reach the root uploads folder
        $imageName = time() . "_" . basename($_FILES['image']['name']);
        $targetFile = $targetDir . $imageName;

        // Move file to target folder
        if (!move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            echo "Failed to upload image.";
            exit;
        }
    }

    // Save filename (not the full path) in DB
    $sql = "INSERT INTO news (title, content, image) VALUES ('$title', '$content', '$imageName')";
    if ($conn->query($sql)) {
        header("Location: ../admin/reports_admin.php");
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="../design/admin.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=notifications" />
    <title>Document</title>
</head>
<body>
    <?php include '../components/sidebar-side.php'; ?>
    <main>
        <h1>Add News</h1> <br>
        <form class="add_news_sytle" method="post" enctype="multipart/form-data">
            <label>Title:</label><br>
            <input type="text" name="title" required><br><br>
            
            <label>Content:</label><br>
            <textarea name="content" rows="6" required></textarea><br><br>
            
            <label>Image:</label><br>
            <input type="file" name="image"><br><br>
            
            <button type="submit">Add News</button>
            <button><a href="../admin/reports_admin.php">Cancel</a></button>
        </form>   
    </main>
    <footer>wowwers</footer>
</body>
</html>