<?php
session_start();
include '../components/db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // 1. Sanitize input
    $event_id = filter_input(INPUT_POST, 'event_id', FILTER_SANITIZE_NUMBER_INT);
    $user_id = filter_input(INPUT_POST, 'user_id', FILTER_SANITIZE_NUMBER_INT);
    $address = filter_input(INPUT_POST, 'address', FILTER_SANITIZE_STRING);
    $phone_number = !empty($_POST['phone_number']) ? filter_input(INPUT_POST, 'phone_number', FILTER_SANITIZE_STRING) : NULL;
    $reason = !empty($_POST['reason']) ? filter_input(INPUT_POST, 'reason', FILTER_SANITIZE_STRING) : NULL;
    $age = filter_input(INPUT_POST, 'age', FILTER_SANITIZE_NUMBER_INT);
    $sex = filter_input(INPUT_POST, 'sex', FILTER_SANITIZE_STRING);

    // 2. Check if user is logged in
    if (empty($user_id) || $user_id === '0') {
        echo "<script>alert('⚠️ Please log in before joining.'); window.location.href='../user/login.php';</script>";
        exit();
    }

    // 3. Check for required fields
    if (empty($event_id) || empty($address) || empty($age) || empty($sex)) {
        echo "<script>alert('❌ Missing required information.'); window.location.href='../user/user.php';</script>";
        exit();
    }

    // 4. Check if already joined
    $check_sql = "SELECT volunteer_event_id FROM volunteer_events WHERE user_id = ? AND event_id = ?";
    if ($check_stmt = $conn->prepare($check_sql)) {
        $check_stmt->bind_param("ii", $user_id, $event_id);
        $check_stmt->execute();
        $check_stmt->store_result();

        if ($check_stmt->num_rows > 0) {
            // Already joined
            $check_stmt->close();
            $conn->close();
            echo "<script>alert('⚠️ You have already joined this event.'); window.location.href='../user/user.php';</script>";
            exit();
        }
        $check_stmt->close();
    } else {
        echo "<script>alert('❌ Database error: " . addslashes($conn->error) . "'); window.location.href='../user/user.php';</script>";
        exit();
    }

    // 5. Insert new record with default status "pending"
    $default_status = 'pending';
    $sql = "INSERT INTO volunteer_events (user_id, event_id, address, phone_number, reason, age, sex, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("iisssiss", $user_id, $event_id, $address, $phone_number, $reason, $age, $sex, $default_status);

        if ($stmt->execute()) {
            echo "<script>alert('✅ Success! You have successfully volunteered for the event.'); window.location.href='../user/user.php';</script>";
        } else {
            echo "<script>alert('❌ Error joining the event: " . addslashes($stmt->error) . "'); window.location.href='../user/user.php';</script>";
        }

        $stmt->close();
    } else {
        echo "<script>alert('❌ Database error: " . addslashes($conn->error) . "'); window.location.href='../user/user.php';</script>";
    }

    $conn->close();
    exit();

} else {
    header("Location: ../user/user.php");
    exit();
}
?>
